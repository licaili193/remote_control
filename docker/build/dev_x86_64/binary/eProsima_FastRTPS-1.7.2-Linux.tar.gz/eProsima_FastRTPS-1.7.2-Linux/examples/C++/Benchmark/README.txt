To launch this test open two different consoles:

In the first one launch: 'BenchMark publisher tcp' or 'BenchMark publisher udp' (or BenchMark.exe publisher on windows).
In the second one: 'BenchMark subscriber tcp' or 'BenchMark subscriber udp'



