To launch this test open two different consoles:

In the first one launch: HelloWorldExampleTCP publisher (or HelloWorldExampleTCP.exe publisher on windows).
In the second one: HelloWorldExampleTCP subscriber.


